#include <iostream>

using namespace std;

int main()
{
    cout << "Success!" << endl;
    return 0;
}