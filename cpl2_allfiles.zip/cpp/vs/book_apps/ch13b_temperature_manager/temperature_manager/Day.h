#ifndef MURACH_DAY_H
#define MURACH_DAY_H

struct Day {
    double low_temp, high_temp;
};

#endif // MURACH_DAY_H